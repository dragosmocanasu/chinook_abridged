# chinook_abridged
Full-Stack Application using the Chinook Abridged DB
