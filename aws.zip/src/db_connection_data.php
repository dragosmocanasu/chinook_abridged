<?php
    $host = 'database-1.cujxmoyqqjlb.us-east-1.rds.amazonaws.com';
    $db = 'chinook_abridged';
    $username = 'admin';
    $password = 'dragosparola';
    $charset = 'utf8mb4';
?>